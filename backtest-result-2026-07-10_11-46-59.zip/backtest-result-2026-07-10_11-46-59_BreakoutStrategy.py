from __future__ import annotations

import pandas as pd

try:
    from freqtrade.strategy import IStrategy
except ImportError:
    class IStrategy:  # type: ignore[no-redef]
        pass


class BreakoutStrategy(IStrategy):
    INTERFACE_VERSION = 3
    can_short = False
    timeframe = "1h"
    startup_candle_count = 20
    minimal_roi = {"0": 100.0}
    stoploss = -0.10
    use_exit_signal = True

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["previous_high"] = dataframe["high"].rolling(5, min_periods=5).max().shift()
        dataframe["previous_low"] = dataframe["low"].rolling(3, min_periods=3).min().shift()
        dataframe["volume_sma20"] = dataframe["volume"].rolling(20, min_periods=1).mean()
        true_range = pd.concat([
            dataframe["high"] - dataframe["low"],
            (dataframe["high"] - dataframe["close"].shift()).abs(),
            (dataframe["low"] - dataframe["close"].shift()).abs(),
        ], axis=1).max(axis=1)
        dataframe["atr"] = true_range.rolling(14, min_periods=1).mean()
        dataframe["atr_percent"] = dataframe["atr"] / dataframe["close"] * 100
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[(dataframe["close"] > dataframe["previous_high"]) & (dataframe["volume"] >= dataframe["volume_sma20"]) & (dataframe["atr_percent"] < 3.5), "enter_long"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[dataframe["close"] < dataframe["previous_low"], "exit_long"] = 1
        return dataframe
