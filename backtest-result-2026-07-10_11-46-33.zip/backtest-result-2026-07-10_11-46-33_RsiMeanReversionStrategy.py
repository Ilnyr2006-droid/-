from __future__ import annotations

import pandas as pd

try:
    from freqtrade.strategy import IStrategy
except ImportError:
    class IStrategy:  # type: ignore[no-redef]
        pass


class RsiMeanReversionStrategy(IStrategy):
    INTERFACE_VERSION = 3
    can_short = False
    timeframe = "1h"
    startup_candle_count = 30
    minimal_roi = {"0": 100.0}
    stoploss = -0.02
    use_exit_signal = True

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        delta = dataframe["close"].diff()
        gains = delta.clip(lower=0).rolling(6, min_periods=6).sum()
        losses = (-delta.clip(upper=0)).rolling(6, min_periods=6).sum()
        dataframe["rsi_simple"] = (100 - (100 / (1 + gains / losses.replace(0, pd.NA)))).fillna(100)
        dataframe["volume_sma20"] = dataframe["volume"].rolling(20, min_periods=1).mean()
        directional_up = dataframe["high"].diff().clip(lower=0)
        directional_down = (-dataframe["low"].diff()).clip(lower=0)
        denominator = (directional_up + directional_down).rolling(14, min_periods=1).sum()
        dataframe["adx_proxy"] = (100 * (directional_up - directional_down).abs().rolling(14, min_periods=1).sum() / denominator.replace(0, pd.NA)).fillna(0)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[(dataframe["rsi_simple"] < 45) & (dataframe["adx_proxy"] < 20) & (dataframe["volume"] >= dataframe["volume_sma20"]), "enter_long"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe.loc[dataframe["rsi_simple"] > 55, "exit_long"] = 1
        return dataframe
