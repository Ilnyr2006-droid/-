from __future__ import annotations

import pandas as pd

try:
    from freqtrade.strategy import IStrategy
except ImportError:  # Allows static security checks without installing Freqtrade locally.
    class IStrategy:  # type: ignore[no-redef]
        pass


class EmaCrossoverStrategy(IStrategy):
    INTERFACE_VERSION = 3
    can_short = False
    timeframe = "1h"
    startup_candle_count = 30
    minimal_roi = {"0": 100.0}
    stoploss = -0.01
    use_exit_signal = True

    def populate_indicators(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        dataframe["ema_fast"] = dataframe["close"].ewm(span=12, adjust=False).mean()
        dataframe["ema_slow"] = dataframe["close"].ewm(span=26, adjust=False).mean()
        dataframe["ema20"] = dataframe["close"].ewm(span=20, adjust=False).mean()
        dataframe["ema20_slope"] = dataframe["ema20"].pct_change()
        dataframe["volume_sma20"] = dataframe["volume"].rolling(20, min_periods=1).mean()
        true_range = pd.concat([
            dataframe["high"] - dataframe["low"],
            (dataframe["high"] - dataframe["close"].shift()).abs(),
            (dataframe["low"] - dataframe["close"].shift()).abs(),
        ], axis=1).max(axis=1)
        dataframe["atr"] = true_range.rolling(14, min_periods=1).mean()
        dataframe["atr_percent"] = dataframe["atr"] / dataframe["close"] * 100
        directional_up = dataframe["high"].diff().clip(lower=0)
        directional_down = (-dataframe["low"].diff()).clip(lower=0)
        denominator = (directional_up + directional_down).rolling(14, min_periods=1).sum()
        dataframe["adx_proxy"] = (100 * (directional_up - directional_down).abs().rolling(14, min_periods=1).sum() / denominator.replace(0, pd.NA)).fillna(0)
        return dataframe

    def populate_entry_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        conditions = (
            (dataframe["ema_fast"].shift() <= dataframe["ema_slow"].shift())
            & (dataframe["ema_fast"] > dataframe["ema_slow"])
            & (dataframe["adx_proxy"] >= 20)
            & (dataframe["ema20_slope"].abs() >= 0.0005)
            & (dataframe["atr_percent"] < 3.5)
            & (dataframe["volume"] >= dataframe["volume_sma20"])
        )
        dataframe.loc[conditions, "enter_long"] = 1
        return dataframe

    def populate_exit_trend(self, dataframe: pd.DataFrame, metadata: dict) -> pd.DataFrame:
        conditions = (dataframe["ema_fast"].shift() >= dataframe["ema_slow"].shift()) & (dataframe["ema_fast"] < dataframe["ema_slow"])
        dataframe.loc[conditions, "exit_long"] = 1
        return dataframe
